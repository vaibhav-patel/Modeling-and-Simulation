% Alternative MATLAB Tutorial 7 Answers
% Name:

%% 
%%% From Tutorial 1

%% QRQ 9a

%% 
%%% From Tutorial 2
%%% 
%% 
%%% From Tutorial 3
%%% 
%% 
%%% From Tutorial 4
%%% 
%% 
%%% From Tutorial 5
%%% 
%% 
%%% From Tutorial 6
%%% 
%% 
%%% From Tutorial 7
%%% 

%% 
%%% For Module 13.5 from Tutorial 2
%%% 
%% 
%%% For Module 13.5 from Tutorial 3
%%% 
%% 
%%% For Module 13.5 from Tutorial 4
%%% 
%% 
%%% For Module 13.5 from Tutorial 5
%%% 
%% 
%%% For Module 13.5 from Tutorial 7
%%% 
